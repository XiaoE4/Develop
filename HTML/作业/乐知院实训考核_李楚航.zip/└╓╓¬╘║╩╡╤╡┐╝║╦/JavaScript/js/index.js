import {ajax,pajax} from  "./util.js"
class todoList {
    constructor(a) {
        // 主属性
        this.main=document.querySelector(a)
        this.catalog=document.querySelector('.list-catalog')
        this.label=document.querySelector('.list-label')
        //清单目录
        this.catalogOne=document.querySelector('.catalog-one')
        //标签
        this.labelBtn=document.querySelector('.list-label a')
        this.labelAddBtm=document.querySelector('.list-label a:nth-child(3)')
        this.labelLi=document.querySelectorAll('.list-label ul li')
        this.labelUl=document.querySelector('.list-label ul')
        this.labelAddInput=document.querySelector('#labelAddInput')
        //    右侧页面清单内容
        this.contentUl=document.querySelector('.list-content')
        this.contentLi=document.querySelectorAll('.content-li')
        this.init()
    }
    init(){
        // this.render()
        this.labelOn()
        this.labelAdd()
        this.getData()
    }
//    渲染页面
    render(){
        console.log(this.listdata1)
        this.contentUl.innerHTML=this.listdata1.map(item=>
        `
        <div class="content-li">
            ${item.name}
        </div>
        `).join("")
        // if(this.listdata2.name){
        //
        // }
        let ul=this.catalogOne.childNodes[1]
        ul.innerHTML=this.listdata2.map(item=>
        `
        <li><a href="#">${item.name}</a></li>
        `
        ).join("")
        console.log(ul.innerHTML)

    }
    //浮现label标签
    labelOn(){
        let i=0
        this.labelBtn.addEventListener("click",()=>{
            // 点击让标签浮动
           i+=1
            if(i%2){
                this.catalog.style.height='500px'
                this.label.style.height='295px'
                if(this.label.height = '295px'){
                    this.labelUl.style.display='block'
                    this.labelAddBtm.style.display='block'
                    this.labelAddInput.style.display='block'
                }
            }else{
                this.catalog.style.height='750px'
                this.label.style.height='45px'
                if(this.label.height = '45px'){
                    this.labelUl.style.display='none'
                    this.labelAddBtm.style.display='none'
                    this.labelAddInput.style.display='none'
                }
            }
            pajax({
                url:""
            })
        })
    }
    //添加label标签
    labelAdd(){
        this.labelAddBtm.addEventListener("click",()=>{
            this.labelAddInput.style.display='block'
            let n =this.labelLi.length
            console.log(this.labelUl)
            // console.log(this.labelAddInput.value)
            let li =document.createElement('li')
            li.innerHTML=`<li>${this.labelAddInput.value}</li>`
            console.log(li.innerText)
            if(li.innerText.length!==0){
                this.labelUl.appendChild(li)
            }else{
                alert('请输入标签名')
            }
        })
    }
    // 获取数据
    getData(){
       pajax({
           url:"http://localhost:3000/lists",
           method:"GET",
       }).then(list=>{
           console.log("list:",list)
           this.listdata1=list
           // this.render()
            return pajax({
                url:"http://localhost:3000/label",
                method:"GET"
            })
       }).then(label=>{
           console.log("label：",label)
           this.listdata2=label
           this.render()
       }).catch(err=>{
           console.log("err:",err)
       })
    }

}




let obj =new todoList(".right-todo")
console.log('obj:',obj)