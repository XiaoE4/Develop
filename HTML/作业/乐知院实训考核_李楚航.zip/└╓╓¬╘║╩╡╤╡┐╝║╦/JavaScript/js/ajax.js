let xhr=new XMLHttpRequest()
console.log(xhr);
xhr.open()