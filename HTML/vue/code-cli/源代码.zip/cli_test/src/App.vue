<template>
  <div>
      <router-view></router-view>
  </div>
</template>

<script>

// import Banner from "@/pages/Banner.vue";
// import Login from "@/pages/Login.vue"
// import CreateAccount from "@/pages/CreateAccount.vue";

export default {
  name: 'App',
  // components: {Login},
  // components:{Login} ,

  data() {
    return {
      
    };
  },

  mounted() {
    
  },

  methods: {
    
  },
};
</script>

<style>

</style>